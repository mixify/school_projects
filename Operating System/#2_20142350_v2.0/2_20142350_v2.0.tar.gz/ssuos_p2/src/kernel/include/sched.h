#ifndef		__SCHED_H__
#define		__SCHED_H__

#include <list.h>

void schedule(void);
extern bool need_sched;

#endif
